# kompBackend
Backend part of website kompservice71 or something else
<br>It's server part of website with REST API and queries to MongoDB
